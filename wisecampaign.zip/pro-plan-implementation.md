# WiseCampaign Pro Plan Implementation Guide

This document outlines the architectural strategy for implementing Pro features within the WiseCampaign modular system (specifically for `wiseBannerV2` and `wiseStockBar`).

## 1. Detection Mechanism

The "Pro" status implementation relies on two layers of verification:
1. **Plugin Presence**: Checking if `wisecampaign-pro` is active.
2. **License Validation**: An API call or option check ensuring the license is active.

### Backend Implementation (`Register.php`)
The `get_pro_status()` method in `WISECAMPAIGN\Classes\Register` should be the source of truth. It checks the license status via a local setting or remote validation.

```php
public function is_pro_active() {
    $license = get_option('wisecampaign_pro_license_status');
    return (defined('WISECAMPAIGN_PRO_ACTIVE') && $license === 'active');
}
```

## 2. Frontend Synchronization

To make this data available to our React modules, we must pass the status during script enqueuing.

### Modular Manager Update (`ModuleManager.php`)
The `wiseModuleData` global object should include `isPro`.

```php
wp_localize_script($module['handle'], 'wiseModuleData', [
    'apiUrl' => rest_url('wisecampaign/v1/'),
    'nonce' => wp_create_nonce('wp_rest'),
    'moduleId' => $id,
    'isPro' => \WISECAMPAIGN\Classes\Register::getInstance()->get_pro_status()
]);
```

## 3. UI/UX Strategy (React Editor)

### Feature Locking Component
Create a reusable `ProFeature` wrapper to handle locked states.

```javascript
const ProFeature = ({ children, isLocked, featureName }) => {
    if (!isLocked) return children;

    return (
        <div className="relative group overflow-hidden">
            {/* Disabled Overlay */}
            <div className="absolute inset-0 bg-white/40 backdrop-blur-[1px] z-10 cursor-not-allowed flex flex-col items-center justify-center transition-all opacity-0 group-hover:opacity-100">
                <button className="bg-blue-600 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-lg">
                    UPGRADE TO PRO
                </button>
            </div>
            
            {/* The Actual UI (Desaturated/Blurred) */}
            <div className="filter grayscale opacity-60 pointer-events-none">
                {children}
            </div>
            
            {/* Pro Badge */}
            <div className="absolute top-1 right-1 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-md shadow-sm uppercase tracking-tighter">
                Pro
            </div>
        </div>
    );
};
```

### Proposed Pro Features Layout
1. **Banner Position**: Add a toggle/select in the `Settings` tab.
2. **Trigger Timing**: Add "Wait Time (Seconds)" and "On Scroll" options under a new "Triggers" section.

## 4. Backend Integrity

The REST API controllers must prevent saving Pro settings if the user is on the Free version.

### `WiseBannerV2.php` REST Controller
```php
public function save_banner_settings(WP_REST_Request $request) {
    if (!Register::getInstance()->get_pro_status()) {
        $params = $request->get_json_params();
        // Force-reset Pro fields to defaults
        unset($params['position']);
        unset($params['triggerDelay']);
    }
    update_option('wc-wisebanner-v2-active', $params);
}
```

## 5. Storefront Execution

The frontend script must receive the full configuration but only execute Pro logic if verified.

### Trigger Logic
1. **Default**: Show immediately on `DOMContentLoaded`.
2. **Pro (Timed)**: Use `setTimeout(() => render(), delay * 1000)`.
3. **Pro (Scroll)**: Use `window.addEventListener('scroll', () => { if(window.scrollY > 300) render() })`.

### Positioning
1. **Top**: Enqueue at `wp_body_open`.
2. **Bottom**: Enqueue at `wp_footer`.

---

## 📈 Roadmap for Pro Features

| Feature | Tab | Component | Logic |
| :--- | :--- | :--- | :--- |
| **Position (Top/Bottom)** | Settings | Display Locations | `fixed bottom-0` vs `relative top-0` |
| **Time Delay** | Settings | Display Triggers | `setTimeout` in `main.jsx` |
| **Scroll Trigger** | Settings | Display Triggers | Intersection Observer |
| **Dismiss Control** | Design | Dismiss Button | Persistent `localStorage` hide |
